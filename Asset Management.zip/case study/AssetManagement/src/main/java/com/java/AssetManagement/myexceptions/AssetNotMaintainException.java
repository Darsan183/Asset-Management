package com.java.AssetManagement.myexceptions;

public class AssetNotMaintainException extends Exception {
	
    public AssetNotMaintainException(String message) {
        super(message);
    }
}